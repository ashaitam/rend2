#include "tools.h"

#include <cmath>

double norm(const Point& p) {
    return std::sqrt(p.x * p.x + p.y * p.y);
}

double distance(const Point& p1, const Point& p2) {
    double dx = p1.x - p2.x;
    double dy = p1.y - p2.y;
    return std::sqrt(dx * dx + dy * dy);
}

bool intersects(const Square& s1, const Square& s2) {
    bool overlap_x =
        std::abs(s1.center.x - s2.center.x) - (s1.side + s2.side) / 2.0 < 0.0;
    bool overlap_y =
        std::abs(s1.center.y - s2.center.y) - (s1.side + s2.side) / 2.0 < 0.0;

    return overlap_x && overlap_y;
}

bool intersects(const Circle& c1, const Circle& c2) {
    return distance(c1.center, c2.center) - (c1.radius + c2.radius) < 0.0;
}

bool intersects(const Circle& c, const Square& s) {
    double square_left = s.center.x - (s.side / 2.0);
    double square_right = s.center.x + (s.side / 2.0);
    double square_top = s.center.y + (s.side / 2.0);
    double square_bottom = s.center.y - (s.side / 2.0);

    double closest_px;
    double closest_py;

    if (c.center.x < square_left) {
        closest_px = square_left;
    } else if (c.center.x > square_right) {
        closest_px = square_right;
    } else {
        closest_px = c.center.x;
    }

    if (c.center.y < square_bottom) {
        closest_py = square_bottom;
    } else if (c.center.y > square_top) {
        closest_py = square_top;
    } else {
        closest_py = c.center.y;
    }

    Point closest_p(closest_px, closest_py);
    return distance(c.center, closest_p) - c.radius < 0.0;
}

bool intersects(const Square& s, const Circle& c) {
    return intersects(c, s);
}

bool intersects_with_epsil(const Square& s1, const Square& s2) {
    bool overlap_x =
        std::abs(s1.center.x - s2.center.x) - (s1.side + s2.side) / 2.0
        < epsil_zero;
    bool overlap_y =
        std::abs(s1.center.y - s2.center.y) - (s1.side + s2.side) / 2.0
        < epsil_zero;

    return overlap_x && overlap_y;
}

bool intersects_with_epsil(const Circle& c1, const Circle& c2) {
    return distance(c1.center, c2.center) - (c1.radius + c2.radius)
           < epsil_zero;
}

bool intersects_with_epsil(const Circle& c, const Square& s) {
    double square_left = s.center.x - (s.side / 2.0);
    double square_right = s.center.x + (s.side / 2.0);
    double square_top = s.center.y + (s.side / 2.0);
    double square_bottom = s.center.y - (s.side / 2.0);

    double closest_px;
    double closest_py;

    if (c.center.x < square_left) {
        closest_px = square_left;
    } else if (c.center.x > square_right) {
        closest_px = square_right;
    } else {
        closest_px = c.center.x;
    }

    if (c.center.y < square_bottom) {
        closest_py = square_bottom;
    } else if (c.center.y > square_top) {
        closest_py = square_top;
    } else {
        closest_py = c.center.y;
    }

    Point closest_p(closest_px, closest_py);
    return distance(c.center, closest_p) - c.radius < epsil_zero;
}

bool intersects_with_epsil(const Square& s, const Circle& c) {
    return intersects_with_epsil(c, s);
}

void Square::draw(Color color) const
{
    draw_square(center.x, center.y, side, color);
}

void Circle::draw(Color color) const
{
    draw_circle(center.x, center.y, radius, color);
}
